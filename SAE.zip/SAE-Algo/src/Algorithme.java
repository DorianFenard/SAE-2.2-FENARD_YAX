/**
 * Interface Algorithme
 *
 */
public interface Algorithme {
    public Valeur solve(Graphe g, String depart);
}
